﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserAPI.Models.ViewModels
{
    public class AccessTokenViewModel
    {
        public string ACCESSTOKEN { get; set; }
    }
}