﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Web.Http;
using ESApi.Models;

namespace ESApi.Controllers
{
    public class CategoryAPIController : ApiController
    {
       
    }
}
