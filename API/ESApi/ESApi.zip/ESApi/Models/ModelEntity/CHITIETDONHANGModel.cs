﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ESApi.Models.ModelEntity
{
    public class CHITIETDONHANGModel
    {
        public string DONHANG { get; set; }
        public string SANPHAM { get; set; }
        public int SOLUONG { get; set; }
        public double THANHTIEN { get; set; }
        public bool DAXOA { get; set; }
    }
}