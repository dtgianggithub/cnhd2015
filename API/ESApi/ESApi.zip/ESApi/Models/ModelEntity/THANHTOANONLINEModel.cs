﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ESApi.Models.ModelEntity
{
    public class THANHTOANONLINEModel
    {
        public int MA { get; set; }
        public string EMAIL { get; set; }
        public int MATHANHVIEN { get; set; }
        public bool DAXOA { get; set; }
    }
}