﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ESApi.Models.ModelEntity
{
    public class TRANGTHAIDONHANGModel
    {
        public int MA { get; set; }
        public string TINHTRANG { get; set; }
        public bool DAXOA { get; set; }
    }
}