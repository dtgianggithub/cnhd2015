﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ESApi.Models.ModelEntity
{
    public class LOAITHANHVIENModel
    {
        public int MA { get; set; }
        public string TENLOAI { get; set; }
        public bool DAXOA { get; set; }
    }
}